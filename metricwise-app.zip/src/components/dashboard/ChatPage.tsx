import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useAuth } from '@/contexts/AuthContext';
import { Send, Users, MessageCircle } from 'lucide-react';

interface Message {
  id: string;
  sender: string;
  content: string;
  timestamp: string;
  isCurrentUser: boolean;
}

interface ChatRoom {
  id: string;
  name: string;
  type: 'project' | 'general' | 'team';
  unreadCount: number;
  lastMessage: string;
  lastMessageTime: string;
}

export const ChatPage: React.FC = () => {
  const { user } = useAuth();
  const [selectedRoom, setSelectedRoom] = useState<string>('1');
  const [newMessage, setNewMessage] = useState('');

  // Mock chat rooms
  const chatRooms: ChatRoom[] = [
    {
      id: '1',
      name: 'Kitchen Renovation Team',
      type: 'project',
      unreadCount: 3,
      lastMessage: 'Installation completed on schedule',
      lastMessageTime: '10:30 AM',
    },
    {
      id: '2',
      name: 'General Discussion',
      type: 'general',
      unreadCount: 0,
      lastMessage: 'Great work everyone!',
      lastMessageTime: '9:15 AM',
    },
    {
      id: '3',
      name: 'Management Team',
      type: 'team',
      unreadCount: 1,
      lastMessage: 'Weekly meeting scheduled',
      lastMessageTime: 'Yesterday',
    },
  ];

  // Mock messages for selected room
  const messages: Message[] = [
    {
      id: '1',
      sender: 'John Smith',
      content: 'Good morning team! Ready to start the kitchen installation today.',
      timestamp: '9:00 AM',
      isCurrentUser: false,
    },
    {
      id: '2',
      sender: 'You',
      content: 'Yes, all materials are ready. Should we start with the cabinets?',
      timestamp: '9:05 AM',
      isCurrentUser: true,
    },
    {
      id: '3',
      sender: 'Sarah Johnson',
      content: 'Perfect! I\'ll handle the upper cabinets while Mike works on the lower ones.',
      timestamp: '9:10 AM',
      isCurrentUser: false,
    },
    {
      id: '4',
      sender: 'Mike Wilson',
      content: 'Sounds like a plan. The client mentioned they want to be present during installation.',
      timestamp: '9:15 AM',
      isCurrentUser: false,
    },
  ];

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      // In a real app, this would send the message to the backend
      console.log('Sending message:', newMessage);
      setNewMessage('');
    }
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const getRoomTypeColor = (type: string) => {
    switch (type) {
      case 'project':
        return 'default';
      case 'team':
        return 'secondary';
      case 'general':
        return 'outline';
      default:
        return 'outline';
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Team Chat</h1>
        <p className="text-gray-600 mt-2">Communicate with your team members</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[600px]">
        {/* Chat Rooms List */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageCircle className="h-5 w-5" />
              Channels
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="h-[500px]">
              <div className="space-y-2 p-4">
                {chatRooms.map((room) => (
                  <div
                    key={room.id}
                    className={`p-3 rounded-lg cursor-pointer transition-colors ${
                      selectedRoom === room.id
                        ? 'bg-blue-50 border-blue-200 border'
                        : 'hover:bg-gray-50'
                    }`}
                    onClick={() => setSelectedRoom(room.id)}
                  >
                    <div className="flex justify-between items-start mb-1">
                      <h4 className="font-medium text-sm">{room.name}</h4>
                      {room.unreadCount > 0 && (
                        <Badge variant="destructive" className="text-xs">
                          {room.unreadCount}
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-gray-600 truncate">{room.lastMessage}</p>
                    <div className="flex justify-between items-center mt-2">
                      <Badge variant={getRoomTypeColor(room.type)} className="text-xs">
                        {room.type}
                      </Badge>
                      <span className="text-xs text-gray-500">{room.lastMessageTime}</span>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Chat Messages */}
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              {chatRooms.find(room => room.id === selectedRoom)?.name}
            </CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col h-[500px]">
            <ScrollArea className="flex-1 mb-4">
              <div className="space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex gap-3 ${
                      message.isCurrentUser ? 'justify-end' : 'justify-start'
                    }`}
                  >
                    {!message.isCurrentUser && (
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className="text-xs">
                          {getInitials(message.sender)}
                        </AvatarFallback>
                      </Avatar>
                    )}
                    <div
                      className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                        message.isCurrentUser
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-100 text-gray-900'
                      }`}
                    >
                      {!message.isCurrentUser && (
                        <p className="text-xs font-medium mb-1">{message.sender}</p>
                      )}
                      <p className="text-sm">{message.content}</p>
                      <p
                        className={`text-xs mt-1 ${
                          message.isCurrentUser ? 'text-blue-100' : 'text-gray-500'
                        }`}
                      >
                        {message.timestamp}
                      </p>
                    </div>
                    {message.isCurrentUser && (
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className="text-xs">
                          {getInitials(user?.name || 'You')}
                        </AvatarFallback>
                      </Avatar>
                    )}
                  </div>
                ))}
              </div>
            </ScrollArea>

            {/* Message Input */}
            <div className="flex gap-2">
              <Input
                placeholder="Type your message..."
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                className="flex-1"
              />
              <Button onClick={handleSendMessage}>
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};