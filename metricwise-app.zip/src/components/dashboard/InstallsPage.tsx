import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { useAuth } from '@/contexts/AuthContext';
import { Search, Plus, MapPin, Calendar, Users } from 'lucide-react';

interface Installation {
  id: string;
  projectName: string;
  client: string;
  address: string;
  status: 'planning' | 'in-progress' | 'completed' | 'on-hold';
  progress: number;
  startDate: string;
  endDate: string;
  teamSize: number;
  priority: 'low' | 'medium' | 'high';
}

export const InstallsPage: React.FC = () => {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  // Mock installations data
  const mockInstalls: Installation[] = [
    {
      id: '1',
      projectName: 'Kitchen Renovation - Downtown',
      client: 'Johnson Family',
      address: '123 Main St, Downtown',
      status: 'in-progress',
      progress: 65,
      startDate: '2024-01-10',
      endDate: '2024-01-25',
      teamSize: 4,
      priority: 'high',
    },
    {
      id: '2',
      projectName: 'Bathroom Remodel - Suburbs',
      client: 'Smith Residence',
      address: '456 Oak Ave, Suburbs',
      status: 'planning',
      progress: 15,
      startDate: '2024-01-20',
      endDate: '2024-02-05',
      teamSize: 2,
      priority: 'medium',
    },
    {
      id: '3',
      projectName: 'Office Space Build-out',
      client: 'Tech Corp Inc.',
      address: '789 Business Blvd, City Center',
      status: 'completed',
      progress: 100,
      startDate: '2023-12-15',
      endDate: '2024-01-08',
      teamSize: 6,
      priority: 'high',
    },
  ];

  const filteredInstalls = mockInstalls.filter(install => {
    const matchesSearch = install.projectName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         install.client.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || install.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'default';
      case 'in-progress':
        return 'secondary';
      case 'planning':
        return 'outline';
      case 'on-hold':
        return 'destructive';
      default:
        return 'outline';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'text-red-600';
      case 'medium':
        return 'text-yellow-600';
      case 'low':
        return 'text-green-600';
      default:
        return 'text-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Installations</h1>
          <p className="text-gray-600 mt-2">Track and manage installation projects</p>
        </div>
        {(user?.role === 'manager' || user?.role === 'office') && (
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            New Installation
          </Button>
        )}
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search installations..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="planning">Planning</SelectItem>
            <SelectItem value="in-progress">In Progress</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="on-hold">On Hold</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid gap-6">
        {filteredInstalls.map((install) => (
          <Card key={install.id}>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-xl">{install.projectName}</CardTitle>
                  <CardDescription className="mt-1 text-base">
                    Client: {install.client}
                  </CardDescription>
                </div>
                <div className="flex gap-2">
                  <Badge variant={getStatusColor(install.status)}>
                    {install.status}
                  </Badge>
                  <Badge variant="outline" className={getPriorityColor(install.priority)}>
                    {install.priority}
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-2 text-gray-600">
                <MapPin className="h-4 w-4" />
                <span>{install.address}</span>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Progress</span>
                  <span>{install.progress}%</span>
                </div>
                <Progress value={install.progress} className="h-2" />
              </div>

              <div className="flex items-center justify-between text-sm text-gray-600">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1">
                    <Calendar className="h-4 w-4" />
                    {new Date(install.startDate).toLocaleDateString()} - {new Date(install.endDate).toLocaleDateString()}
                  </div>
                  <div className="flex items-center gap-1">
                    <Users className="h-4 w-4" />
                    {install.teamSize} team members
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline">
                    View Details
                  </Button>
                  {install.status !== 'completed' && (
                    <Button size="sm">
                      Update Progress
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};