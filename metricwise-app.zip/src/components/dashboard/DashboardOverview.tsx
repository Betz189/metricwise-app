import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';
import { 
  CheckCircle, 
  Clock, 
  AlertCircle, 
  Users,
  Wrench,
  MessageSquare
} from 'lucide-react';

export const DashboardOverview: React.FC = () => {
  const { user } = useAuth();

  const stats = [
    {
      title: 'Active Installs',
      value: '12',
      description: 'Currently in progress',
      icon: Wrench,
      color: 'text-blue-600',
    },
    {
      title: 'Pending Tasks',
      value: '8',
      description: 'Awaiting completion',
      icon: Clock,
      color: 'text-yellow-600',
    },
    {
      title: 'Completed Today',
      value: '5',
      description: 'Tasks finished',
      icon: CheckCircle,
      color: 'text-green-600',
    },
    {
      title: 'Team Members',
      value: '24',
      description: 'Active users',
      icon: Users,
      color: 'text-purple-600',
    },
  ];

  const recentActivity = [
    {
      id: '1',
      title: 'Kitchen Install - 123 Main St',
      status: 'completed',
      time: '2 hours ago',
    },
    {
      id: '2',
      title: 'Bathroom Renovation - 456 Oak Ave',
      status: 'in-progress',
      time: '4 hours ago',
    },
    {
      id: '3',
      title: 'Flooring Install - 789 Pine St',
      status: 'pending',
      time: '6 hours ago',
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Welcome back, {user?.name}!</h1>
        <p className="text-gray-600 mt-2">Here's what's happening with your projects today.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.title}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                <Icon className={`h-4 w-4 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                <p className="text-xs text-gray-600">{stat.description}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest project updates</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivity.map((activity) => (
                <div key={activity.id} className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{activity.title}</p>
                    <p className="text-sm text-gray-600">{activity.time}</p>
                  </div>
                  <Badge 
                    variant={
                      activity.status === 'completed' ? 'default' :
                      activity.status === 'in-progress' ? 'secondary' : 'outline'
                    }
                  >
                    {activity.status}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Common tasks for {user?.role}s</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {user?.role === 'manager' && (
                <>
                  <button className="w-full text-left p-3 rounded-lg hover:bg-gray-50 border">
                    Create New Install
                  </button>
                  <button className="w-full text-left p-3 rounded-lg hover:bg-gray-50 border">
                    Assign Tasks
                  </button>
                </>
              )}
              {user?.role === 'installer' && (
                <>
                  <button className="w-full text-left p-3 rounded-lg hover:bg-gray-50 border">
                    View My Tasks
                  </button>
                  <button className="w-full text-left p-3 rounded-lg hover:bg-gray-50 border">
                    Upload Progress Photos
                  </button>
                </>
              )}
              <button className="w-full text-left p-3 rounded-lg hover:bg-gray-50 border">
                View Messages
              </button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};