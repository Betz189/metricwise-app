import React, { useState } from 'react';
import { Sidebar } from './Sidebar';
import { DashboardOverview } from './DashboardOverview';
import { TaskList } from './TaskList';
import { SettingsPage } from './SettingsPage';
import { TeamPage } from './TeamPage';
import { InstallsPage } from './InstallsPage';
import { ChatPage } from './ChatPage';
import { useIsMobile } from '@/hooks/use-mobile';

export const MainDashboard: React.FC = () => {
  const [currentPage, setCurrentPage] = useState('dashboard');
  const isMobile = useIsMobile();

  const renderContent = () => {
    switch (currentPage) {
      case 'dashboard':
        return <DashboardOverview />;
      case 'tasks':
        return <TaskList />;
      case 'installs':
        return <InstallsPage />;
      case 'team':
        return <TeamPage />;
      case 'chat':
        return <ChatPage />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <DashboardOverview />;
    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {!isMobile && (
        <Sidebar 
          currentPage={currentPage} 
          onPageChange={setCurrentPage}
        />
      )}
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {isMobile && (
          <div className="bg-white border-b p-4 flex items-center justify-between">
            <h1 className="text-xl font-bold text-blue-600">Metricwise</h1>
            <Sidebar 
              currentPage={currentPage} 
              onPageChange={setCurrentPage}
              isMobile={true}
            />
          </div>
        )}
        
        <main className="flex-1 overflow-auto p-6">
          {renderContent()}
        </main>
      </div>
    </div>
  );
};