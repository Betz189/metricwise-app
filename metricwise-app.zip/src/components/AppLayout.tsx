import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { AuthPage } from './auth/AuthPage';
import { MainDashboard } from './dashboard/MainDashboard';

const AppLayout: React.FC = () => {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return isAuthenticated ? <MainDashboard /> : <AuthPage />;
};

export default AppLayout;
