export interface Task {
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'in-progress' | 'completed';
  assignedTo: string;
  assignedBy: string;
  dueDate: string;
  priority: 'low' | 'medium' | 'high';
  images?: string[];
}

export interface Install {
  id: string;
  title: string;
  description: string;
  address: string;
  status: 'scheduled' | 'in-progress' | 'completed' | 'cancelled';
  assignedTeam: string[];
  startDate: string;
  endDate?: string;
  tasks: Task[];
  images?: string[];
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  message: string;
  timestamp: string;
  installId?: string;
}